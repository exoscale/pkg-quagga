Protobuf definitions and code that is applicable to all of quagga.
